# First iPad test

1. Install via TestFlight. Keep Translate audio OFF.
2. Prepare session; verify the preview renders; tap Float subtitles.
3. Tap the system broadcast button and Start Broadcast, then open TikTok.
4. Play a LIVE with audible speech for 30 seconds. Verify the floating window remains visible, updates status, and says Sound detected. Return to Suwan and check the audio-seconds counter.
5. Stop from iPad's broadcast indicator. Confirm the capture indicator disappears.
6. Only if the above passes: add your own OpenAI API key in the installed app, enable translation and consent, prepare, float, broadcast and return to TikTok.
7. Listen for 60 seconds. Check caption updates and whether they match the speaker. Expect at least five seconds plus network/service delay; sentence splits and slang can degrade results.
8. Switch away from Suwan for two minutes. Check that captions keep changing. If they freeze, capture and PiP background operation need further work.
9. Test silence, muting, headphones, Wi-Fi interruption, stopping, resuming, closing PiP, and a 15-minute session limit. Never assume headphones or background capture work before testing.

Acceptance: moving English window over TikTok, ongoing speech translations, no interruption of TikTok audio, and a reliable stop. Do not describe this prototype as working until these pass.

If audio stays at zero: verify playback and the Suwan broadcast selection. Test another non-protected audio app to distinguish TikTok capture restrictions from an extension/signing problem.

If the meter moves but translations fail: read the app status for rejected keys, quota/rate limits or HTTP failures. API errors end capture without automatic retries.

If PiP won't open or playback stops: this is the unresolved iPad compatibility gate. A successful cloud build cannot resolve it by itself.
