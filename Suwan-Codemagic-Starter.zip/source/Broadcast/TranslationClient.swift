import Foundation

final class TranslationClient {
    private let session: URLSession = {
        let c = URLSessionConfiguration.ephemeral
        c.timeoutIntervalForRequest = 20
        c.timeoutIntervalForResource = 25
        c.urlCache = nil
        return URLSession(configuration: c)
    }()
    private var task: URLSessionDataTask?
    func cancel() { task?.cancel(); task = nil }
    func translate(_ wav: Data, key: String, completion: @escaping (Result<String, Error>) -> Void) {
        let boundary = UUID().uuidString
        var body = Data()
        func append(_ s: String) { body.append(Data(s.utf8)) }
        for (name, value) in [("model", "whisper-1"), ("response_format", "json"), ("temperature", "0")] {
            append("--\(boundary)\r\nContent-Disposition: form-data; name=\"\(name)\"\r\n\r\n\(value)\r\n")
        }
        append("--\(boundary)\r\nContent-Disposition: form-data; name=\"file\"; filename=\"segment.wav\"\r\nContent-Type: audio/wav\r\n\r\n")
        body.append(wav); append("\r\n--\(boundary)--\r\n")
        var request = URLRequest(url: URL(string: "https://api.openai.com/v1/audio/translations")!)
        request.httpMethod = "POST"
        request.setValue("Bearer \(key)", forHTTPHeaderField: "Authorization")
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        request.httpBody = body
        task = session.dataTask(with: request) { data, response, error in
            if let error { completion(.failure(error)); return }
            let code = (response as? HTTPURLResponse)?.statusCode ?? 0
            guard code == 200, let data else {
                let message: String
                switch code {
                case 401: message = "API key rejected. Save a valid key in Suwan."
                case 429: message = "API quota or rate limit reached. Check API billing."
                default: message = "Translation request failed (HTTP \(code)). Stop and retry."
                }
                completion(.failure(NSError(domain: "Translation", code: code, userInfo: [NSLocalizedDescriptionKey: message]))); return
            }
            struct Reply: Decodable { let text: String }
            do { completion(.success(try JSONDecoder().decode(Reply.self, from: data).text)) }
            catch { completion(.failure(error)) }
        }
        task?.resume()
    }
}
