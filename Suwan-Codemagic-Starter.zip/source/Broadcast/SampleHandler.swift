import ReplayKit

final class SampleHandler: RPBroadcastSampleHandler {
    private let queue = DispatchQueue(label: "Suwan.capture")
    private let chunker = AudioChunker()
    private let client = TranslationClient()
    private var state = CaptureState()
    private var translating = false
    private var busy = false
    private var generation = UUID()
    private var timer: DispatchSourceTimer?
    private var lastAudio = Date()
    private var started = Date()
    private var lastWrite = Date.distantPast
    private var pending: (Data, Double)?
    private var paused = false
    override func broadcastStarted(withSetupInfo setupInfo: [String: NSObject]?) {
        queue.async { [self] in
            guard SharedStore.directory != nil else { fail("App Group unavailable. Check signing profiles."); return }
            generation = UUID(); state = CaptureState(); state.active = true
            translating = SharedStore.settings.translate
            if translating && KeyStore.read() == nil { fail("Save your API key before translating."); return }
            state.status = translating ? "Waiting for app audio" : "Audio test: waiting for sound"
            started = Date(); lastAudio = Date(); paused = false
            chunker.onLevel = { [weak self] level, seconds in
                guard let self else { return }
                self.state.level = level; self.state.audioSeconds += seconds; self.lastAudio = Date()
            }
            chunker.onChunk = { [weak self] data, rms, seconds in
                guard let self else { return }
                guard self.translating else {
                    self.state.status = rms > 0.003 ? "Audio test: sound detected" : "Audio test: silent audio received"
                    self.publish(); return
                }
                guard rms > 0.003 else {
                    if !self.busy { self.state.status = "Listening — quiet audio" }
                    return
                }
                if self.busy {
                    if self.pending != nil { self.state.droppedChunks += 1 }
                    self.pending = (data, seconds) // Only one waiting segment; bounded memory and delay.
                } else { self.submit(data, seconds: seconds) }
            }
            let timer = DispatchSource.makeTimerSource(queue: queue)
            timer.schedule(deadline: .now(), repeating: 1)
            timer.setEventHandler { [weak self] in self?.tick() }
            self.timer = timer; timer.resume(); publish()
        }
    }
    override func processSampleBuffer(_ sampleBuffer: CMSampleBuffer, with sampleBufferType: RPSampleBufferType) {
        // Video and microphone data are discarded; only application audio is handled.
        guard sampleBufferType == .audioApp else { return }
        queue.sync {
            guard state.active, !paused else { return }
            do { try chunker.consume(sampleBuffer) }
            catch { fail("Unsupported captured audio: \(error.localizedDescription)") }
        }
    }
    private func tick() {
        guard state.active else { return }
        if SharedStore.settings.stop { fail("Stopped by you"); return }
        if Date().timeIntervalSince(started) >= 15 * 60 { fail("15-minute prototype session ended. Start again to continue."); return }
        if !paused && Date().timeIntervalSince(lastAudio) > 8 {
            state.status = "No app audio received. Check TikTok playback."
            state.level = 0
        }
        publish()
    }
    private func submit(_ data: Data, seconds: Double) {
        guard let key = KeyStore.read(), !key.isEmpty else { fail("API key missing"); return }
        busy = true; state.status = "Translating Japanese → English"; publish()
        let token = generation
        client.translate(data, key: key) { [weak self] result in
            guard let self else { return }
            self.queue.async {
                guard self.state.active, token == self.generation else { return }
                self.busy = false
                switch result {
                case .success(let text):
                    self.state.translatedSeconds += seconds
                    let clean = text.trimmingCharacters(in: .whitespacesAndNewlines)
                    if !clean.isEmpty { self.state.caption = String(clean.prefix(1500)); self.state.captionUpdated = Date().timeIntervalSince1970 }
                    self.state.status = "Listening"
                case .failure(let error):
                    self.fail(error.localizedDescription); return // No unbounded paid retries.
                }
                self.publish()
                if let next = self.pending { self.pending = nil; self.submit(next.0, seconds: next.1) }
            }
        }
    }
    private func publish() {
        state.updated = Date().timeIntervalSince1970
        do { try SharedStore.write(state, name: "state.json") }
        catch { cleanup(); finishBroadcastWithError(error) }
    }
    private func cleanup() {
        state.active = false; generation = UUID(); client.cancel(); busy = false
        pending = nil; chunker.reset(); timer?.cancel(); timer = nil
    }
    private func fail(_ message: String) {
        cleanup(); state.status = message; state.level = 0
        try? SharedStore.write(state, name: "state.json")
        finishBroadcastWithError(NSError(domain: "Suwan", code: 1, userInfo: [NSLocalizedDescriptionKey: message]))
    }
    override func broadcastPaused() {
        queue.async { [self] in
            paused = true; generation = UUID(); client.cancel(); busy = false; pending = nil
            chunker.reset(); state.level = 0; state.status = "Broadcast paused"; publish()
        }
    }
    override func broadcastResumed() {
        queue.async { [self] in paused = false; lastAudio = Date(); state.status = "Listening"; publish() }
    }
    override func broadcastFinished() {
        queue.async { [self] in cleanup(); state.status = "Broadcast stopped"; state.level = 0; publish() }
    }
}
