import AVFoundation

// ReplayKit may deliver different sample rates, channel layouts and sample types.
// AVAudioConverter normalizes these to bounded 16 kHz mono PCM.
final class AudioChunker {
    private var converter: AVAudioConverter?
    private var inputFormat: AVAudioFormat?
    private let output = AVAudioFormat(commonFormat: .pcmFormatFloat32, sampleRate: 16_000, channels: 1, interleaved: false)!
    private var pcm = Data()
    private var squared: Double = 0
    private var count = 0
    var onChunk: ((Data, Float, Double) -> Void)?
    var onLevel: ((Float, Double) -> Void)?
    func reset() { pcm.removeAll(keepingCapacity: true); squared = 0; count = 0; converter = nil; inputFormat = nil }
    func consume(_ sample: CMSampleBuffer) throws {
        guard let description = CMSampleBufferGetFormatDescription(sample) else { return }
        let candidate: AVAudioFormat? = AVAudioFormat(cmAudioFormatDescription: description)
        guard let format = candidate,
              let buffer = AVAudioPCMBuffer(pcmFormat: format, frameCapacity: AVAudioFrameCount(CMSampleBufferGetNumSamples(sample))) else { return }
        buffer.frameLength = buffer.frameCapacity
        let copied = CMSampleBufferCopyPCMDataIntoAudioBufferList(sample, at: 0, frameCount: Int32(buffer.frameLength), into: buffer.mutableAudioBufferList)
        guard copied == noErr else { throw NSError(domain: "AudioCopy", code: Int(copied)) }
        if inputFormat != format {
            reset(); inputFormat = format; converter = AVAudioConverter(from: format, to: output)
        }
        guard let converter else { throw NSError(domain: "AudioFormat", code: 1) }
        let capacity = AVAudioFrameCount(ceil(Double(buffer.frameLength) * 16_000 / format.sampleRate)) + 64
        guard let converted = AVAudioPCMBuffer(pcmFormat: output, frameCapacity: capacity) else { return }
        var supplied = false
        var conversionError: NSError?
        let status = converter.convert(to: converted, error: &conversionError) { _, state in
            if supplied { state.pointee = .noDataNow; return nil }
            supplied = true; state.pointee = .haveData; return buffer
        }
        if status == .error { throw conversionError ?? NSError(domain: "AudioConvert", code: 1) }
        guard let floats = converted.floatChannelData?[0] else { return }
        var energy: Double = 0
        for index in 0..<Int(converted.frameLength) {
            let v = max(-1, min(1, floats[index].isFinite ? floats[index] : 0))
            let e = Double(v * v); energy += e; squared += e; count += 1
            var value = Int16(v * 32767).littleEndian
            withUnsafeBytes(of: &value) { pcm.append(contentsOf: $0) }
            if count == 80_000 { // Five seconds, ~160 KB, no accumulated recording.
                onChunk?(Self.wav(pcm), Float(sqrt(squared / Double(count))), 5)
                pcm.removeAll(keepingCapacity: true); squared = 0; count = 0
            }
        }
        if converted.frameLength > 0 {
            onLevel?(Float(sqrt(energy / Double(converted.frameLength))), Double(converted.frameLength) / 16_000)
        }
    }
    static func wav(_ pcm: Data) -> Data {
        var data = Data()
        func text(_ s: String) { data.append(Data(s.utf8)) }
        func number<T: FixedWidthInteger>(_ n: T) {
            var value = n.littleEndian
            withUnsafeBytes(of: &value) { data.append(contentsOf: $0) }
        }
        text("RIFF"); number(UInt32(36 + pcm.count)); text("WAVEfmt ")
        number(UInt32(16)); number(UInt16(1)); number(UInt16(1))
        number(UInt32(16_000)); number(UInt32(32_000)); number(UInt16(2)); number(UInt16(16))
        text("data"); number(UInt32(pcm.count)); data.append(pcm)
        return data
    }
}
