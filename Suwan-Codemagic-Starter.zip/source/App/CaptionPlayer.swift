import AVKit
import SwiftUI

final class CaptionSurface: UIView {
    override class var layerClass: AnyClass { AVSampleBufferDisplayLayer.self }
    var displayLayer: AVSampleBufferDisplayLayer { layer as! AVSampleBufferDisplayLayer }
}
struct CaptionPreview: UIViewRepresentable {
    let player: CaptionPlayer
    func makeUIView(context: Context) -> CaptionSurface { player.surface }
    func updateUIView(_ uiView: CaptionSurface, context: Context) {}
}
final class CaptionPlayer: NSObject, ObservableObject, AVPictureInPictureControllerDelegate, AVPictureInPictureSampleBufferPlaybackDelegate {
    let surface = CaptionSurface()
    @Published var message = "Prepare the window, then start a broadcast."
    @Published var floating = false
    private var controller: AVPictureInPictureController?
    private var timer: Timer?
    private var timebase: CMTimebase?
    private var lastCaption = ""
    override init() {
        super.init()
        surface.backgroundColor = .black
        surface.displayLayer.videoGravity = .resizeAspect
    }
    func prepare() {
        guard AVPictureInPictureController.isPictureInPictureSupported() else {
            message = "Picture in Picture is unavailable on this device."; return
        }
        do {
            let session = AVAudioSession.sharedInstance()
            try session.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])
            try session.setActive(true)
        } catch { message = error.localizedDescription; return }
        if controller == nil {
            CMTimebaseCreateWithSourceClock(allocator: kCFAllocatorDefault, sourceClock: CMClockGetHostTimeClock(), timebaseOut: &timebase)
            if let timebase {
                CMTimebaseSetTime(timebase, time: .zero)
                CMTimebaseSetRate(timebase, rate: 1)
                surface.displayLayer.controlTimebase = timebase
            }
            let source = AVPictureInPictureController.ContentSource(sampleBufferDisplayLayer: surface.displayLayer, playbackDelegate: self)
            controller = AVPictureInPictureController(contentSource: source)
            controller?.delegate = self
            controller?.requiresLinearPlayback = true
        }
        if timer == nil {
            let t = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in self?.render() }
            RunLoop.main.add(t, forMode: .common); timer = t
        }
        render(); message = "Window ready. Tap Float subtitles, then start the broadcast."
    }
    func start() {
        if controller == nil { prepare() }
        guard let controller, controller.isPictureInPicturePossible else {
            message = "Window isn't ready yet. Keep the preview visible, wait a moment and try again."; return
        }
        controller.startPictureInPicture()
    }
    func stop() {
        controller?.stopPictureInPicture()
        timer?.invalidate(); timer = nil
        surface.displayLayer.flushAndRemoveImage()
        try? AVAudioSession.sharedInstance().setActive(false, options: [.notifyOthersOnDeactivation])
    }
    private func render() {
        let state = SharedStore.state
        let stale = state.active && Date().timeIntervalSince1970 - state.updated > 8
        let recent = Date().timeIntervalSince1970 - state.captionUpdated < 20
        let title = stale ? "Capture status unavailable — reopen Suwan" : state.status
        let caption = state.active && recent ? state.caption : (state.active ? "Waiting for Japanese speech…" : "English subtitles will appear here.")
        let size = CGSize(width: 960, height: 540)
        let format = UIGraphicsImageRendererFormat(); format.scale = 1; format.opaque = true
        let image = UIGraphicsImageRenderer(size: size, format: format).image { context in
            UIColor(red: 0.035, green: 0.043, blue: 0.075, alpha: 1).setFill(); context.fill(CGRect(origin: .zero, size: size))
            let style = NSMutableParagraphStyle(); style.alignment = .left; style.lineBreakMode = .byWordWrapping
            ("SUWAN  •  JAPANESE → ENGLISH" as NSString).draw(in: CGRect(x: 40, y: 30, width: 880, height: 45), withAttributes: [.font: UIFont.systemFont(ofSize: 23, weight: .semibold), .foregroundColor: UIColor.systemTeal])
            // A segment may be long; fit it rather than silently truncate the caption.
            var fontSize: CGFloat = 43
            let rect = CGRect(x: 40, y: 105, width: 880, height: 325)
            while fontSize > 20 {
                let bounds = (caption as NSString).boundingRect(with: CGSize(width: rect.width, height: .greatestFiniteMagnitude), options: [.usesLineFragmentOrigin, .usesFontLeading], attributes: [.font: UIFont.systemFont(ofSize: fontSize, weight: .medium), .paragraphStyle: style], context: nil)
                if bounds.height <= rect.height { break }; fontSize -= 1
            }
            (caption as NSString).draw(in: rect, withAttributes: [.font: UIFont.systemFont(ofSize: fontSize, weight: .medium), .foregroundColor: UIColor.white, .paragraphStyle: style])
            (title as NSString).draw(in: CGRect(x: 40, y: 465, width: 880, height: 65), withAttributes: [.font: UIFont.systemFont(ofSize: 22), .foregroundColor: UIColor.lightGray, .paragraphStyle: style])
        }
        guard let cg = image.cgImage else { return }
        var pixel: CVPixelBuffer?
        let attrs: [CFString: Any] = [kCVPixelBufferCGImageCompatibilityKey: true, kCVPixelBufferCGBitmapContextCompatibilityKey: true, kCVPixelBufferIOSurfacePropertiesKey: [:]]
        guard CVPixelBufferCreate(kCFAllocatorDefault, 960, 540, kCVPixelFormatType_32ARGB, attrs as CFDictionary, &pixel) == kCVReturnSuccess, let pixel else { return }
        CVPixelBufferLockBaseAddress(pixel, [])
        if let ctx = CGContext(data: CVPixelBufferGetBaseAddress(pixel), width: 960, height: 540, bitsPerComponent: 8, bytesPerRow: CVPixelBufferGetBytesPerRow(pixel), space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipFirst.rawValue) {
            ctx.draw(cg, in: CGRect(origin: .zero, size: size))
        }
        CVPixelBufferUnlockBaseAddress(pixel, [])
        var description: CMVideoFormatDescription?
        guard CMVideoFormatDescriptionCreateForImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: pixel, formatDescriptionOut: &description) == noErr, let description else { return }
        let now = timebase.map { CMTimebaseGetTime($0) } ?? CMTime.zero
        var timing = CMSampleTimingInfo(duration: CMTime(value: 1, timescale: 2), presentationTimeStamp: now, decodeTimeStamp: .invalid)
        var sample: CMSampleBuffer?
        guard CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: pixel, formatDescription: description, sampleTiming: &timing, sampleBufferOut: &sample) == noErr, let sample else { return }
        if surface.displayLayer.status == .failed { surface.displayLayer.flush() }
        if surface.displayLayer.isReadyForMoreMediaData { surface.displayLayer.enqueue(sample) }
    }
    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, setPlaying playing: Bool) {}
    func pictureInPictureControllerTimeRangeForPlayback(_ pictureInPictureController: AVPictureInPictureController) -> CMTimeRange {
        CMTimeRange(start: .zero, duration: .positiveInfinity)
    }
    func pictureInPictureControllerIsPlaybackPaused(_ pictureInPictureController: AVPictureInPictureController) -> Bool { false }
    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, didTransitionToRenderSize newRenderSize: CMVideoDimensions) {}
    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, skipByInterval skipInterval: CMTime, completionHandler: @escaping () -> Void) { completionHandler() }
    func pictureInPictureControllerDidStartPictureInPicture(_ pictureInPictureController: AVPictureInPictureController) { floating = true; message = "Floating window active. Start the broadcast, then open TikTok." }
    func pictureInPictureControllerDidStopPictureInPicture(_ pictureInPictureController: AVPictureInPictureController) {
        floating = false; message = "Window closed. Translation is stopping."
        var settings = SharedStore.settings; settings.stop = true
        try? SharedStore.write(settings, name: "settings.json")
        timer?.invalidate(); timer = nil
    }
    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, failedToStartPictureInPictureWithError error: Error) { message = "Floating window failed: \(error.localizedDescription)" }
    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, restoreUserInterfaceForPictureInPictureStopWithCompletionHandler completionHandler: @escaping (Bool) -> Void) { completionHandler(true) }
}
