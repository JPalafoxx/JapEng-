import SwiftUI
import ReplayKit

@main struct SuwanApp: App {
    var body: some Scene { WindowGroup { ContentView().preferredColorScheme(.dark) } }
}
struct BroadcastButton: UIViewRepresentable {
    func makeUIView(context: Context) -> RPSystemBroadcastPickerView {
        let picker = RPSystemBroadcastPickerView(frame: CGRect(x: 0, y: 0, width: 60, height: 60))
        picker.preferredExtension = Bundle.main.object(forInfoDictionaryKey: "BroadcastBundle") as? String
        picker.showsMicrophoneButton = false
        return picker
    }
    func updateUIView(_ uiView: RPSystemBroadcastPickerView, context: Context) {}
}
struct ContentView: View {
    @StateObject private var player = CaptionPlayer()
    @State private var key = ""
    @State private var hasKey = KeyStore.read() != nil
    @State private var translate = false
    @State private var consent = false
    @State private var prepared = false
    @State private var feedback = ""
    @State private var state = SharedStore.state
    private let clock = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 24) {
                HStack {
                    Image(systemName: "captions.bubble.fill").font(.largeTitle).foregroundStyle(.mint)
                    VStack(alignment: .leading) {
                        Text("Suwan Translate").font(.largeTitle.bold())
                        Text("Japanese → English · iPad prototype").foregroundStyle(.secondary)
                    }
                }
                CaptionPreview(player: player).aspectRatio(16 / 9, contentMode: .fit).clipShape(RoundedRectangle(cornerRadius: 18))
                    .accessibilityLabel("English subtitle preview")
                Text(player.message).foregroundStyle(.mint)
                GroupBox("1. Choose a session") {
                    VStack(alignment: .leading, spacing: 14) {
                        Toggle("Translate audio into English", isOn: $translate)
                        Text(translate ? "Sends five-second app-audio segments to OpenAI. API charges apply. Captions have a delay and may make mistakes." : "Audio test only: shows whether app sound is received. No audio is uploaded; no translation key needed.").foregroundStyle(.secondary)
                        if translate {
                            SecureField("Your OpenAI API key", text: $key).textInputAutocapitalization(.never).autocorrectionDisabled().textFieldStyle(.roundedBorder)
                            HStack {
                                Button("Save key") {
                                    do { try KeyStore.save(key.trimmingCharacters(in: .whitespacesAndNewlines)); key = ""; hasKey = true; feedback = "Key saved on this iPad." }
                                    catch { feedback = error.localizedDescription }
                                }.disabled(key.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                                Button("Remove key", role: .destructive) { KeyStore.delete(); hasKey = false; feedback = "Key removed." }
                                Text(hasKey ? "Key saved" : "No key saved").foregroundStyle(.secondary)
                            }
                            Toggle("I agree to send captured app audio to OpenAI for translation", isOn: $consent)
                        }
                        if !feedback.isEmpty { Text(feedback).foregroundStyle(.secondary) }
                    }.padding(.vertical, 10)
                }.disabled(state.active)
                GroupBox("2. Open the floating window") {
                    VStack(alignment: .leading, spacing: 14) {
                        Button("Prepare session") {
                            do {
                                try SharedStore.write(RunSettings(translate: translate, stop: false), name: "settings.json")
                                try SharedStore.write(CaptureState(), name: "state.json")
                                prepared = true; feedback = ""; player.prepare()
                            } catch { feedback = error.localizedDescription }
                        }.buttonStyle(.borderedProminent).disabled(state.active || (translate && (!hasKey || !consent)))
                        Button("Float subtitles") { player.start() }.buttonStyle(.bordered).disabled(!prepared)
                        Text("Keep the preview visible while opening the floating window. You can move and resize it.").foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 10)
                }
                GroupBox("3. Start capture, then open TikTok") {
                    HStack(spacing: 20) {
                        BroadcastButton().frame(width: 60, height: 60).disabled(!prepared || !player.floating)
                            .accessibilityLabel("Start or stop Suwan screen broadcast")
                        Text("Tap the broadcast button and choose Start Broadcast. Then open your Japanese TikTok LIVE. Leave the microphone off.")
                    }.padding(.vertical, 10)
                }
                GroupBox("Session status") {
                    VStack(alignment: .leading, spacing: 10) {
                        Text(state.active && Date().timeIntervalSince1970 - state.updated > 8 ? "Capture status is stale. Check the system broadcast indicator." : state.status)
                        ProgressView(value: min(Double(state.level) * 12, 1)).tint(.mint).accessibilityLabel("Captured audio level")
                        Text("Audio received: \(Int(state.audioSeconds)) s · Translated: \(Int(state.translatedSeconds)) s · Skipped segments: \(state.droppedChunks)").font(.callout).foregroundStyle(.secondary)
                        Button("Stop session", role: .destructive) {
                            var s = SharedStore.settings; s.stop = true
                            try? SharedStore.write(s, name: "settings.json"); player.stop(); prepared = false
                        }.buttonStyle(.bordered)
                        Text("To stop immediately, use iPad’s screen-broadcast indicator. Closing the floating window also requests a stop. Sessions end after 15 minutes.").font(.callout).foregroundStyle(.secondary)
                    }.frame(maxWidth: .infinity, alignment: .leading).padding(.vertical, 10)
                }
                Text("TikTok compatibility is unverified. Video frames and microphone audio are discarded. The latest caption is stored locally and replaced as new text arrives. This is a personal prototype, not an App Store release.")
                    .font(.callout).foregroundStyle(.secondary)
            }.padding(28).frame(maxWidth: 800)
        }.background(Color(red: 0.035, green: 0.043, blue: 0.075))
        .onReceive(clock) { _ in state = SharedStore.state }
        .onChange(of: translate) { _, _ in prepared = false }
    }
}
