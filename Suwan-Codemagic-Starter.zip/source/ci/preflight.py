import os, pathlib, re
root = pathlib.Path(__file__).resolve().parents[1]
bundle = os.environ.get('APP_BUNDLE_ID', '')
if not re.fullmatch(r'[A-Za-z][A-Za-z0-9-]*(?:\.[A-Za-z][A-Za-z0-9-]*){2,}', bundle) or bundle == 'com.yourname.suwan':
    raise SystemExit('Set your unique bundle ID in codemagic.yaml (both occurrences) and project.yml first. See START-HERE.md.')
project = (root / 'project.yml').read_text()
match = re.search(r'^    APP_BUNDLE_ID: (.+)$', project, re.M)
if not match or match[1].strip() != bundle:
    raise SystemExit('Bundle ID mismatch: project.yml and codemagic.yaml must use the same ID.')
print('Bundle ID settings match. Signing profiles must include App Groups for both targets.')
