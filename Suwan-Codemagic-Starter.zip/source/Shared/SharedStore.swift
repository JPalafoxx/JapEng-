import Foundation
import Security

struct CaptureState: Codable {
    var active = false
    var status = "Ready for audio test"
    var caption = "English subtitles will appear here."
    var updated = Date().timeIntervalSince1970
    var captionUpdated: Double = 0
    var level: Float = 0
    var audioSeconds: Double = 0
    var translatedSeconds: Double = 0
    var droppedChunks = 0
}
struct RunSettings: Codable {
    var translate = false
    var stop = false
}
enum SharedStore {
    static var group: String { Bundle.main.object(forInfoDictionaryKey: "AppGroup") as? String ?? "" }
    static var directory: URL? { FileManager.default.containerURL(forSecurityApplicationGroupIdentifier: group) }
    static func read<T: Decodable>(_ name: String, fallback: T) -> T {
        guard let url = directory?.appendingPathComponent(name), let data = try? Data(contentsOf: url),
              let value = try? JSONDecoder().decode(T.self, from: data) else { return fallback }
        return value
    }
    static func write<T: Encodable>(_ value: T, name: String) throws {
        guard let dir = directory else { throw NSError(domain: "Suwan", code: 1, userInfo: [NSLocalizedDescriptionKey: "App Group unavailable. Check both signing profiles."]) }
        try JSONEncoder().encode(value).write(to: dir.appendingPathComponent(name), options: [.atomic, .completeFileProtectionUntilFirstUserAuthentication])
    }
    static var state: CaptureState { read("state.json", fallback: CaptureState()) }
    static var settings: RunSettings { read("settings.json", fallback: RunSettings()) }
}
enum KeyStore {
    static var query: [String: Any] {
        [kSecClass as String: kSecClassGenericPassword,
         kSecAttrService as String: "SuwanOpenAI",
         kSecAttrAccount as String: "personal-api-key",
         kSecAttrAccessGroup as String: Bundle.main.object(forInfoDictionaryKey: "KeychainGroup") as? String ?? ""]
    }
    static func read() -> String? {
        var q = query; q[kSecReturnData as String] = true; q[kSecMatchLimit as String] = kSecMatchLimitOne
        var result: CFTypeRef?
        guard SecItemCopyMatching(q as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func save(_ value: String) throws {
        let bytes = Data(value.utf8)
        let status = SecItemUpdate(query as CFDictionary, [kSecValueData as String: bytes] as CFDictionary)
        if status == errSecSuccess { return }
        guard status == errSecItemNotFound else { throw failure(status) }
        var q = query
        q[kSecValueData as String] = bytes
        q[kSecAttrAccessible as String] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        let added = SecItemAdd(q as CFDictionary, nil)
        guard added == errSecSuccess else { throw failure(added) }
    }
    static func delete() { SecItemDelete(query as CFDictionary) }
    static func failure(_ status: OSStatus) -> Error {
        NSError(domain: "Keychain", code: Int(status), userInfo: [NSLocalizedDescriptionKey: "Keychain error \(status). Check shared Keychain signing entitlements."])
    }
}
