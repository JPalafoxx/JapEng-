# Suwan Translate — iPad prototype

A personal Japanese-to-English caption experiment: ReplayKit application audio → five-second 16 kHz WAV segments → OpenAI audio translation → shared latest-caption state → video-backed Picture in Picture. iPadOS 17+.

Status: source prepared, not compiled or device-tested here. See VALIDATION.md and DEVICE-TEST.md.

## Source map
- App/: SwiftUI setup screen and sample-buffer PiP caption player.
- Broadcast/: ReplayKit extension, audio conversion, bounded segment queue, HTTPS translation.
- Shared/: atomic App Group state/settings and shared Keychain credential.
- project.yml: XcodeGen app/extension project definition.
- codemagic.yaml: normal source-repository build workflows.
- ci/preflight.py: signed-build bundle-ID check.

## Limits
Audio test is the default and never makes translation requests. Translation uses whisper-1 /v1/audio/translations; the service supports English output. Five-second chunks are not streaming token-by-token translation and may split words or sentences. An RMS threshold suppresses quiet chunks; this is not full speech detection, so music/noise may still produce unwanted text. One request plus one pending segment bounds backlog; excess segments are explicitly counted as skipped. Requests time out, do not retry automatically, and sessions end after 15 minutes.

The app discards video and microphone buffers, holds short WAV segments in memory, sends application audio to OpenAI only in translation mode, and stores only current caption/status locally. ReplayKit capture is system-wide while enabled, so changing apps changes which app audio may be submitted. Stop before playing other audio you do not want translated. The user enters their own API key after installation; no key is embedded in source or uploaded to Codemagic. This personal BYO-key prototype uses shared Keychain storage. A distributed product should use an authenticated server and short-lived client credentials.

PiP is designed by Apple for media playback. Rendering caption video and mixing audio with TikTok require physical-device validation and do not imply App Store approval. A broadcast extension cannot draw arbitrary UI over other apps.

## References
- https://docs.codemagic.io/yaml-quick-start/building-a-native-ios-app/
- https://docs.codemagic.io/yaml-code-signing/signing-ios/
- https://developer.apple.com/documentation/replaykit/rpbroadcastsamplehandler
- https://developer.apple.com/documentation/avkit/avpictureinpicturesamplebufferplaybackdelegate
- https://developers.openai.com/api/docs/guides/speech-to-text
