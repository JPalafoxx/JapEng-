# Suwan Translate: start from your iPad

This is a prepared native-app prototype, not an installed or verified working translator. The first goal is a successful Codemagic compile. TikTok audio capture and the floating window must then be tested on your physical iPad.

## Part 1 — First cloud compile

You do not need to buy an Apple Developer membership or an OpenAI API key for this step. Codemagic may require account verification and applies its own build quotas/pricing.

1. Save this ZIP in the iPad Files app and tap it to extract it.
2. In Safari, open https://github.com and sign in or create an account. Create a **private** repository named `suwan-translator`. Initialize it with a README. If controls are missing, use Safari's **Request Desktop Website**.
3. In that repository, choose **Add file → Upload files → choose your files**. Select **codemagic.yaml** from the extracted folder. Commit it to the main branch. Upload this one file as-is; do not upload the ZIP. The build file includes the app source in a checksum-verified archive, so there are no folders to upload.
4. Open https://codemagic.io in Safari. Sign in and connect your GitHub account, granting access to this repository.
5. Add an application from the `suwan-translator` repository. Choose a native iOS/Other project and YAML configuration when prompted. Scan the main branch for `codemagic.yaml`.
6. Start the workflow **Suwan - compile check (no Apple membership needed)**, whose ID is `compile-check`.
7. Wait for its result. If it fails, share the first actual compiler error and the few lines around it here. A screenshot of the build result is enough to start. Do not share credentials.

A successful compile checks both the app and its broadcast extension. It does **not** produce an app you can install; the simulator build is a compiler check only.

## Part 2 — Set up an installable TestFlight build

Do this after compile-check passes. Apple Developer Program membership is required for this route. Apple currently lists $99/year in the US; cloud builds and API translation are separate services. Your ChatGPT subscription does not provide API credits.

### A. Register the app with Apple

1. Enroll at https://developer.apple.com/programs/ if you have not already.
2. Choose a unique bundle identifier, for example `com.jpage.suwantranslator`. The example is not reserved or guaranteed available. Once registered, keep it consistent.
3. In **Certificates, Identifiers & Profiles**, register two explicit App IDs:
   - Main app: `com.jpage.suwantranslator`
   - Broadcast extension: `com.jpage.suwantranslator.broadcast`
4. Register an App Group: `group.com.jpage.suwantranslator`. Enable **App Groups** for BOTH App IDs and assign this same group to each.
5. In https://appstoreconnect.apple.com, create the main iOS app record using the main App ID. Choose an available name (Suwan Translate if available), primary language English, and a unique SKU such as `suwan-personal-01`.

### B. Connect Apple to Codemagic

1. In App Store Connect, under **Users and Access → Integrations → App Store Connect API**, create an API key with the App Manager role (API access may first need enabling).
2. In Codemagic Team integrations, connect App Store Connect using that key's issuer ID, key ID, and downloaded `.p8` file. Name the integration exactly **suwan-apple**, matching the workflow. Enter secrets directly in Codemagic, never into GitHub or ChatGPT.
3. In Codemagic's iOS code-signing identities settings, generate an Apple Distribution certificate, or supply an existing certificate and its private key.
4. Fetch/generate App Store distribution provisioning profiles for BOTH App IDs. Both must include the shared App Group and match the distribution certificate. If you change capabilities later, regenerate both profiles.
5. The workflow selects the main profile and matching `.broadcast` extension profile. If signing reports a missing profile or entitlement, verify these profiles before retrying. Keychain sharing is declared in both targets; its access group is built from your Apple App Identifier prefix and main bundle ID.

### C. Change two values and build

1. In GitHub, edit `codemagic.yaml`.
2. In the **testflight** workflow, replace both visible occurrences of `com.yourname.suwan` with your main bundle ID:
   - `environment.ios_signing.bundle_identifier`
   - `environment.vars.APP_BUNDLE_ID`
3. Do not edit the embedded source block. The workflow applies your bundle ID to the generated project automatically. Commit the change.
4. Start **Suwan - signed TestFlight build**. This workflow signs the app and extension and submits the build to TestFlight; it does not submit a public App Store release.
5. After Apple processes the build, in App Store Connect's TestFlight section add yourself to an internal testing group and enable the build for that group. External testing may require beta review; use internal testing for your own prototype when eligible.
6. Install Apple's TestFlight app on your iPad and install Suwan through your testing invitation/account.

## Part 3 — Check TikTok, then enable translation

1. Open Suwan and leave **Translate audio into English** OFF.
2. Tap **Prepare session**, then **Float subtitles**. If it is not ready, keep the preview visible, wait a moment and tap again.
3. Tap the circular system broadcast button and choose **Start Broadcast**. Then switch to TikTok and play Japanese speech.
4. Check for **Audio test: sound detected** in the floating window. Return to Suwan to check that audio seconds increased. Stop using iPad's broadcast indicator.
5. If audio and PiP both work, create an API key at https://platform.openai.com/api-keys with API billing enabled. Enter it in the installed Suwan app, save it, enable translation, and agree to send captured app audio for translation.
6. Prepare, float and broadcast again. English captions should begin after a five-second audio segment plus network/processing delay. This must still be verified; do not assume sub-second captions or perfect accuracy.

The API key stays in the iPad's shared Keychain. Capture sends application audio while enabled, including audio from other apps if you switch apps. Video and microphone buffers are discarded. Each prototype session ends after 15 minutes. Stop from the system broadcast indicator at any time.

## If something fails

- **Compile error:** share the first compiler error; this package was not compiled in the creation environment.
- **Signing error:** verify the main and extension App IDs, App Group, distribution certificate, and both profiles.
- **No TestFlight build:** check the publishing log, Apple processing status, app record, and internal group assignment.
- **No captured audio:** verify the selected broadcast and app playback. TikTok may not provide capturable sound in your setup.
- **PiP closes or freezes over TikTok:** this is the unverified background-playback compatibility gate. A cloud build cannot prove or guarantee this behavior.
- **API error:** read the app status. Rejected credentials, rate limits, quota limits and failed requests stop the session without automatic retries.

## Files in this package

- `codemagic.yaml`: the single file to upload to GitHub; source is embedded for convenient iPad setup.
- `source/`: readable copy of all app source and the normal repository workflow.
- `source/DEVICE-TEST.md`: the physical-device acceptance checklist.
- `source/VALIDATION.md`: exactly what has and has not been verified.

For later source development, use the readable source folder as the repository root instead of the one-file workflow. Update the bundle ID in `project.yml` as well as both values in its normal `codemagic.yaml`. Changes to the readable copy do not modify the embedded source automatically.

## Official references

- Codemagic native iOS builds: https://docs.codemagic.io/yaml-quick-start/building-a-native-ios-app/
- Codemagic signing: https://docs.codemagic.io/yaml-code-signing/signing-ios/
- Apple Developer Program: https://developer.apple.com/programs/
- OpenAI audio translation: https://developers.openai.com/api/docs/guides/speech-to-text
